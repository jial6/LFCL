import sys
import math

# -*- coding: utf-8 -*-
# @Time : 2024/6/9 18:00
# @Author : LiJia

def pivotIndex(nums):
    """
    :type nums: List[int]
    :rtype: int
    """
    n = len(nums)
    left_i, right_i = 0, 0
    left_sum = [0 for _ in range(n)]
    right_sum = [0 for _ in range(n)]

    suml = 0
    for i in range(n):
        left_sum[i] = suml
        suml += nums[i]

    sumr = 0
    for j in range(n-1, -1, -1):
        right_sum[j] = sumr
        sumr += nums[j]

    for i in range(n):
        if left_sum[i] == right_sum[i]:
            return i
    return -1

nums = [1, 7, 3, 6, 5, 6]
print(pivotIndex(nums))