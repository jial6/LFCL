import torch
import torch.optim as optim
import torch.nn as nn

from Model.FinetuneModel import FINALMODEL, NEWMODEL, NEWLMODEL
from Model.PretrainModel import MODEL, TRMODEL, TRMODELL
from SimClr import SimClr
from Model import contrastive_loss

# -*- coding: utf-8 -*-
# @Time : 2023/7/6 9:45
# @Author : LiJia

def get_pretrain_model(name, **kwargs):
    """
    Instantiate and obtain a model with adequate hyperparameters

    Args:
        name: string of the model name
        kwargs: hyperparameters
    Returns:
        models: PyTorch network
        optimizer: PyTorch optimizer
        criterion: PyTorch loss Function
        kwargs: hyperparameters with sane defaults
    """
    device = kwargs.setdefault('device', torch.device('cuda'))  # 给字典添加键值
    n_classes = kwargs['n_classes']
    n_bands = kwargs['n_bands']
    l_bands = kwargs['l_bands']
    batch_size = kwargs['batch_size']
    weights = torch.ones(n_classes)
    weights[torch.LongTensor(kwargs['ignored_labels'])] = 0.
    weights = weights.to(device)
    weights = kwargs.setdefault('weights', weights)
    patch_size = kwargs.setdefault('patch_size', 21)  # 如果'patch_size'键不存在于字典中，将会添加键并将值设为默认值,5
    center_pixel = True

    if name == 'CNN':
        model = MODEL(n_bands, n_classes=128, cl_classes=n_classes, patch_size=patch_size)   # 模型
    elif name == 'CNN-L':
        model = MODEL(l_bands, n_classes=128, cl_classes=n_classes,patch_size=patch_size)
    elif name == 'TTMODEL':
        model = TRMODEL(n_bands, dim=128, cl_classes=n_classes, depth=4, heads=8, mlp_dim=128, dropout=0.1, is_finetune=False)
    elif name == 'TTMODELL':
        model = TRMODELL(l_bands, dim=128, depth=4, heads=8, mlp_dim=128, dropout=0.1, is_finetune=False)
    # elif name == 'CTMODEL':
    #     model = CTMODEL(patch_size=patch_size, in_chans=n_bands, embed_dim=128, depth=4, num_heads=4)
    # elif name == 'CTMODELL':
    #     model = CTMODEL(patch_size=patch_size, in_chans=l_bands, embed_dim=128, depth=4, num_heads=4)

    else:
        raise KeyError("{} model is unknown.".format(name))

    lr = kwargs.setdefault('lr', 0.001)  # LearningRate = 0.075 ×BatchSize的根号
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=0.0005)  # 调换优化器测试,adamw一般 , weight_decay=0.0005
    criterion = SimClr(batch_size=kwargs.setdefault('batch_size', 256),
                       temperature=0.5)  # device=device
    ####聚类####
    criterion_cluster = contrastive_loss.ClusterLoss(n_classes, 1.0, torch.device("cuda")).to(device)
    #criterion_cluster = contrastive_loss.ClusteringLoss(weight_clu_loss=1, regularization_coef=1e-5).to(device)

    model = model.to(device)
    epoch = kwargs.setdefault('epoch', 500)
    kwargs.setdefault('scheduler', optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.1, patience=epoch // 4,
                                                                        verbose=True))
    # 学习率调整，该方法提供了一些基于训练过程中的某些测量值对学习率进行动态的下降，之前的问题可能就是出在这
    # kwargs.setdefault('batch_size', 512)  # （原100）测试一下
    kwargs.setdefault('supervision', 'simclr')
    kwargs.setdefault('flip_augmentation', False)
    kwargs.setdefault('radiation_augmentation', False)
    kwargs.setdefault('mixture_augmentation', False)
    kwargs['center_pixel'] = center_pixel

    return model, optimizer, criterion, criterion_cluster, kwargs

def get_finetune_model(name, **kwargs):
    """
    Instantiate and obtain a model with adequate hyperparameters

    Args:
        name: string of the model name
        kwargs: hyperparameters
    Returns:
        models: PyTorch network
        optimizer: PyTorch optimizer
        criterion: PyTorch loss Function
        kwargs: hyperparameters with sane defaults
    """
    device = kwargs.setdefault('device', torch.device('cuda'))  # 给字典添加键值
    n_classes = kwargs['n_classes']
    n_bands = kwargs['n_bands']
    l_bands = kwargs['l_bands']
    patch_size = kwargs.setdefault('patch_size', 15)  # 如果'patch_size'键不存在于字典中，将会添加键并将值设为默认值,5
    center_pixel = True

    if name == 'NEWMODEL':
        model = NEWMODEL(n_bands, n_classes, patch_size=patch_size)  # 模型
    elif name == 'NEWMODELL':
        model = NEWLMODEL(l_bands, n_classes, patch_size=patch_size) # 模型
    elif name == 'TTMODEL':
        model = TRMODEL(n_bands, cl_classes=n_classes,dim=128, depth=4, heads=8, mlp_dim=128, dropout=0.1, is_finetune=True)
    elif name == 'TTMODELL':
        model = TRMODELL(l_bands, dim=128, depth=4, heads=8, mlp_dim=512, dropout=0.1, is_finetune=True)
    else:
        raise KeyError("{} model is unknown.".format(name))

    model = model.to(device)
    return model

def get_optimizer(model, LR):
    learning_rate = LR
    param_group = []
    # param_group += [{'params': model.blocks.parameters(), 'lr': learning_rate*0.01}]
    param_group += [{'params': model.netH.parameters(), 'lr': learning_rate * 0.5}]  #Houston:0.5
    param_group += [{'params': model.netL.parameters(), 'lr': learning_rate * 0.5}]     #TR
    # optimizer = optim.SGD(param_group, momentum=0.9, weight_decay=5e-4)   # 只对param_group进行计算
    optimizer = optim.Adam(param_group, eps=1e-6, weight_decay=1e-6)
    return optimizer

def get_fmodel(netH, netL, **kwargs):
    device = kwargs.setdefault('device', torch.device('cuda'))
    n_classes = kwargs['n_classes']
    h_bands = kwargs['n_bands']
    l_bands = kwargs['l_bands']
    #l_bands = kwargs['l_bands']

    model = FINALMODEL(h_bands, l_bands, n_classes, netH, netL, patch_size=15)
    lr = kwargs.setdefault('lr', 0.01) # ori 0.001
    optimizer = get_optimizer(model, lr)
    criterion = nn.CrossEntropyLoss()
    model = model.to(device)
    epoch = kwargs.setdefault('epoch', 500)
    kwargs['scheduler']=optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.1, patience=epoch//4, verbose=True)
    #kwargs['scheduler']=optim.lr_scheduler.StepLR(optimizer, step_size=20, gamma=0.75)
    kwargs.setdefault('supervision', 'full')
    kwargs.setdefault('flip_augmentation', False)
    kwargs.setdefault('radiation_augmentation', False)
    kwargs.setdefault('mixture_augmentation', False)
    kwargs['center_pixel'] = True

    return model, optimizer, criterion, kwargs


