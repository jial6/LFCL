import torch

from Model.PretrainModel import LMODEL, MODEL
from attention import *
from bilinear_layers.bilinear_layers import *

# -*- coding: utf-8 -*-
# @Time : 2023/7/6 9:45
# @Author : LiJia

class NEWLMODEL(nn.Module):
    def __init__(self, input_channels, n_classes, patch_size=21):
        super(NEWLMODEL, self).__init__()
        self.patch_size = patch_size
        self.input_channels = input_channels
        self.f = LMODEL(self.input_channels, n_classes, patch_size=self.patch_size).f
        self.fine_projector = nn.Sequential(
            nn.ConvTranspose2d(256, 64, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.Conv2d(64, 10, kernel_size=3, stride=1, padding=0, bias=False)
        )

    def forward(self, x):
        out = self.f(x)
        '''微调的映射头'''
        out = self.fine_projector(out)
        return out

class NEWMODEL(nn.Module):
    def __init__(self, input_channels, n_classes, patch_size=16):
        super(NEWMODEL, self).__init__()
        self.patch_size = patch_size
        self.input_channels = input_channels
        self.f = MODEL(self.input_channels, n_classes, n_classes, patch_size=self.patch_size).f
        self.fine_projector = nn.Sequential(
            nn.ConvTranspose2d(256, 64, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.Conv2d(64, 10, kernel_size=3, stride=1, padding=0, bias=False)
        )


    def forward(self, x):
        out = self.f(x)
        '''微调的映射头'''
        out = self.fine_projector(out)
        return out

class FINALMODEL(nn.Module):
    def __init__(self, inputH_channels, inputL_channels, n_classes, netH, netL, patch_size = 20):
        super(FINALMODEL, self).__init__()
        self.inputH_channels = inputH_channels
        self.inputL_channels = inputL_channels
        self.patch_size = patch_size
        self.n_classes = n_classes

        self.netH = netH
        self.netL = netL
        self.flattened_size = self.flattened()

        self.fc = nn.Sequential(
            nn.Linear(300, n_classes)
        )

        self.fc_new1 = nn.Sequential(
            nn.Linear(100, n_classes, bias=False),
        )

        self.sign_sqrt = sign_sqrt.apply
        self.softmax = nn.Softmax(dim = 1)

        self.downsample_64 = nn.Sequential(
            nn.ConvTranspose2d(64, 32, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.Conv2d(32, 10, kernel_size=3, stride=1, padding=0, bias=False)
        )

        self.downsample_128 = nn.Sequential(
            nn.ConvTranspose2d(128, 32, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.Conv2d(32, 10, kernel_size=3, stride=1, padding=0, bias=False)
        )

        self.downsample_256 = nn.Sequential(
            nn.ConvTranspose2d(256, 32, kernel_size=3, stride=2, padding=1, output_padding=1),
            nn.Conv2d(32, 10, kernel_size=3, stride=1, padding=0, bias=False)
        )

        self._init_parameters()


    def _init_parameters(self):
        for m in self.modules():
            if isinstance(m, torch.nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, nn.Linear):
                nn.init.xavier_uniform_(m.weight.data)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.constant_(m.weight, 1)
                nn.init.constant_(m.bias, 0)


    def flattened(self):  # 此函数没有用到
        with torch.no_grad():
            x = torch.zeros((1, self.inputH_channels, self.patch_size, self.patch_size,))
            x = MODEL(self.inputH_channels,self.inputH_channels, 16, patch_size=self.patch_size).f(x)
            t, w, l, b = x.size()
            return t * w * l * b # 卷积完毕

    def forward(self, data, datal):
        layers = len(self.netH.f)

        feature, feature_l = [], []
        for i in range(layers):
            data = self.netH.f[i](data)
            datal = self.netL.f[i](datal)

            if i == 3 or i == 4:
                if data.shape[1] == 64:
                    feature.append(self.downsample_64(data))
                    feature_l.append(self.downsample_64(datal))
                elif data.shape[1] == 128:
                    feature.append(self.downsample_128(data))
                    feature_l.append(self.downsample_128(datal))
                elif data.shape[1] == 256:
                    feature.append(self.downsample_256(data))
                    feature_l.append(self.downsample_256(datal))

        data = self.netH.fine_projector(data)
        datal = self.netL.fine_projector(datal)
        h_0 = data.view(data.shape[0], data.shape[1], data.shape[2] * data.shape[3])
        l_0 = datal.view(datal.shape[0], datal.shape[1], datal.shape[2] * datal.shape[3])
        X_0 = torch.bmm(h_0, torch.transpose(l_0, 1, 2)) / (h_0.shape[2] ** 2)
        X_0 = self.sign_sqrt(X_0)
        X_0 = X_0.view(X_0.shape[0], X_0.shape[1] * X_0.shape[2])
        X_0 = torch.nn.functional.normalize(X_0)

        for i in range(len(feature)):
            h_ = feature[i].view(feature[i].shape[0], feature[i].shape[1], feature[i].shape[2] * feature[i].shape[3])
            l_ = feature_l[i].view(feature_l[i].shape[0], feature_l[i].shape[1], feature_l[i].shape[2] * feature_l[i].shape[3])
            X = torch.bmm(h_, torch.transpose(l_, 1, 2))/ (h_.shape[2] ** 2)
            X = self.sign_sqrt(X)
            X = X.view(X.shape[0], X.shape[1] * X.shape[2])
            X = torch.nn.functional.normalize(X)
            X_0 = torch.cat((X, X_0), dim = 1)

        # X_0 = self.netL(datal)
        # X_0 = X_0.reshape(datal.shape[0], 640)

        out = self.fc(X_0)

        # #======================last bilinear pooling======================#
        # h = self.netH(data)
        # l = self.netL(datal)
        # h_ = h.view(h.shape[0], h.shape[1], h.shape[2] * h.shape[3])
        # l_ = l.view(l.shape[0], l.shape[1], l.shape[2] * l.shape[3])
        # X = torch.bmm(h_, torch.transpose(l_, 1, 2)) / (h_.shape[2] ** 2)
        # X = self.sign_sqrt(X)
        # X = X.view(X.shape[0], X.shape[1] * X.shape[2])
        # X = torch.nn.functional.normalize(X)
        #
        # out = self.fc_new1(X)

        # return out
        return out
