import torch
from einops import rearrange
from torch import nn
from torchvision.models.resnet import resnet18
import torch.nn.functional as F
from timm.models.vision_transformer import Block

# -*- coding: utf-8 -*-
# @Time : 2023/7/6 9:44
# @Author : LiJia
from VIT import weight_init
from VIT.weight_init import trunc_normal_


class LMODEL(nn.Module):
    def __init__(self, input_channels, n_classes, patch_size):  # 后面使用3d卷积的时候，输入的channels有变化，ori=30，after=64
        super(LMODEL, self).__init__()
        self.f = []
        self.patch_size = patch_size
        self.input_channels = input_channels
        self.n_classes = n_classes
        self.avgpool = nn.AdaptiveAvgPool2d((7,7))

        # resnet18.AdaptiveAvgPool2d
        for name, module in resnet18(pretrained=False).named_children():  # resnet50 may try?
            if name == 'conv1':
                module = nn.Conv2d(self.input_channels, 64, kernel_size=(3, 3), padding=(1, 1), bias=False)
                # HSI通道数与RGB通道数不一致
            if not isinstance(module, nn.Linear) and not isinstance(module, nn.MaxPool2d) and not isinstance(module, nn.AdaptiveAvgPool2d):  # except adaptavg
                self.f.append(module)
            # if isinstance(module, nn.AdaptiveAvgPool2d):
            #     module1 = nn.AdaptiveAvgPool2d((8,8))
            #     self.f.append(module1)
        self.f.remove(self.f[6])

        #self.f[5][1] = nn.Sequential()

        self.f = nn.Sequential(*self.f)

        #backbone_in_channels = resnet18().fc.in_features
        backbone_in_channels = 4096
        self.project = nn.Sequential(
            nn.Linear(backbone_in_channels, 256, bias=False),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Linear(256, 128, bias=True))  # 128

        self.project_f = nn.Sequential(
            nn.Linear(backbone_in_channels, 512, bias=False),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True),
            nn.Linear(512, 256, bias=True)
            )

    #     self._init_parameters()
    #
    # def _init_parameters(self):
    #     for m in self.modules():
    #         if isinstance(m, torch.nn.Conv2d):
    #             nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
    #         elif isinstance(m, nn.Linear):
    #             nn.init.xavier_uniform_(m.weight.data)
    #         elif isinstance(m, nn.BatchNorm2d):
    #             nn.init.constant_(m.weight, 1)
    #             nn.init.constant_(m.bias, 0)

    def forward(self, x):
        x = self.f(x)
        out = torch.flatten(x, start_dim=1)
        out_low = self.project(out)      #128
        out_height = self.project_f(out)    #256

        return out_height, out_low

class MODEL(nn.Module):
    def __init__(self, input_channels, n_classes, cl_classes, patch_size):  # 后面使用3d卷积的时候，输入的channels有变化，ori=30，after=64
        super(MODEL, self).__init__()
        self.f = []
        self.patch_size = patch_size
        self.input_channels = input_channels
        self.cl_classes = cl_classes
        self.n_classes = n_classes
        self.avgpool = nn.AdaptiveAvgPool2d((7,7))
        self.alpha = 1.0

        self.cluster_centers = nn.Parameter(torch.Tensor(cl_classes, 128), requires_grad=True)
        torch.nn.init.xavier_normal_(self.cluster_centers.data)

        # resnet18.AdaptiveAvgPool2d
        for name, module in resnet18(pretrained=False).named_children():  # resnet50 may try?
            if name == 'conv1':
                module = nn.Conv2d(self.input_channels, 64, kernel_size=(3, 3), padding=(1, 1), bias=False)
                # HSI通道数与RGB通道数不一致
            if not isinstance(module, nn.Linear) and not isinstance(module, nn.MaxPool2d) and not isinstance(module, nn.AdaptiveAvgPool2d):  # except adaptavg
                self.f.append(module)

        # 将输出改成256通道
        self.f.remove(self.f[6])
        self.f = nn.Sequential(*self.f)

        #backbone_in_channels = resnet18().fc.in_features
        backbone_in_channels = 4096
        self.project = nn.Sequential(
            nn.Linear(backbone_in_channels, 512, bias=False),
            nn.BatchNorm1d(512),
            nn.ReLU(inplace=True),
            nn.Linear(512, 128, bias=True)
        )

        self.cluster_projector = nn.Sequential(
            nn.Linear(backbone_in_channels, 512, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(512, self.cl_classes, bias=True),
            nn.Softmax(dim=1)
        )

    #     self._init_parameters()
    #
    #
    # def _init_parameters(self):
    #     for m in self.modules():
    #         if isinstance(m, torch.nn.Conv2d):
    #             nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
    #         elif isinstance(m, nn.Linear):
    #             nn.init.xavier_uniform_(m.weight.data)
    #         elif isinstance(m, nn.BatchNorm2d):
    #             nn.init.constant_(m.weight, 1)
    #             nn.init.constant_(m.bias, 0)
    def get_cluster_prob(self, embeddings):
        norm_squared = torch.sum((embeddings.unsqueeze(1) - self.cluster_centers) ** 2, 2)
        numerator = 1.0 / (1.0 + (norm_squared / self.alpha))
        power = float(self.alpha + 1) / 2
        numerator = numerator ** power
        return numerator / torch.sum(numerator, dim=1, keepdim=True)

    def forward(self, x):
        x = self.f(x)
        out = torch.flatten(x, start_dim=1)
        out_c = self.project(out)
        #out_cl = self.cluster_projector(out)
        out_cl = self.get_cluster_prob(out_c)

        return out_c, out_cl



class Residual(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(x, **kwargs) + x

class LayerNormalize(nn.Module):
    def __init__(self, dim, fn):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(self.norm(x), **kwargs)


class MLP_Block(nn.Module):
    def __init__(self, dim, hidden_dim, dropout=0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )

    def forward(self, x):
        return self.net(x)

class Attention(nn.Module):
    def __init__(self, dim, heads=4, dropout=0.1):
        super().__init__()
        self.heads = heads
        self.scale = dim ** -0.5  # 1/sqrt(dim)
        self.in_channels = 1

        self.to_qkv = nn.Linear(dim, dim * 3, bias=True)

        self.nn1 = nn.Linear(dim, dim)
        self.do1 = nn.Dropout(dropout)

    def forward(self, x, mask=None):
        b, n, _, h = *x.shape, self.heads
        qkv = self.to_qkv(x).chunk(3, dim = -1)  # gets q = Q = Wq matmul x1, k = Wk mm x2, v = Wv mm x3
        q, k, v = map(lambda t: rearrange(t, 'b n (h d) -> b h n d', h = 8), qkv)  # split into multi head attentions
        dots = torch.einsum('bhid,bhjd->bhij', q, k) * self.scale
        mask_value = -torch.finfo(dots.dtype).max

        attn = dots.softmax(dim=-1)  # follow the softmax,q,d,v equation in the paper

        out = torch.einsum('bhij,bhjd->bhid', attn, v)  # product of v times whatever inside softmax
        out = rearrange(out, 'b h n d -> b n (h d)')  # concat heads into one matrix, ready for next encoder block
        out = self.nn1(out)
        out = self.do1(out)
        return out

class TRMODEL(nn.Module):
    def __init__(self, in_channels, cl_classes, dim, depth, heads, mlp_dim, dropout, is_finetune):
        super().__init__()

        self.L = 4
        self.cT = dim
        self.is_finetune = is_finetune
        self.cl_classes = cl_classes

        self.conv2d_features2 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels=128, kernel_size=(1, 1))
        )

        self.dropout = nn.Dropout(0.2)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, dim))
        self.pos_embedding = nn.Parameter(torch.zeros(1, 5, dim))

        self.token_wA = nn.Parameter(torch.zeros(1, self.L, dim),
                                     requires_grad=True)  # Tokenization parameters
        torch.nn.init.xavier_normal_(self.token_wA)
        self.token_wV = nn.Parameter(torch.zeros(1, dim, self.cT),
                                     requires_grad=True)  # Tokenization parameters
        torch.nn.init.xavier_normal_(self.token_wV)

        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Residual(LayerNormalize(dim, Attention(dim, heads=heads, dropout=dropout))),
                Residual(LayerNormalize(dim, MLP_Block(dim, mlp_dim, dropout=dropout)))
            ]))

        self._init_weights()

        backbone_in_channels = 640
        self.projection = nn.Sequential(
            nn.Linear(backbone_in_channels, 256, bias=False),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Linear(256, 128, bias=True)
        )

        self.cluster_projector = nn.Sequential(
            nn.Linear(backbone_in_channels, 512, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(512, self.cl_classes, bias=True),
            nn.Softmax(dim=1)
        )

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.bias, 0)
                nn.init.constant_(m.weight, 1.0)

    def forward(self, x, mask=None):
        batch_size, channels, height, width = x.shape
        x = self.conv2d_features2(x)
        x = rearrange(x, 'b c h w -> b (h w) c')

        wa2 = rearrange(self.token_wA, 'b h w -> b w h')  # Transpose
        A2 = torch.einsum('bij,bjk->bik', x, wa2)
        A2 = rearrange(A2, 'b h w -> b w h')  # Transpose
        A2 = A2.softmax(dim=-1)

        VV2 = torch.einsum('bij,bjk->bik', x, self.token_wV)
        T2 = torch.einsum('bij,bjk->bik', A2, VV2)

        cls_tokens = self.cls_token.expand(x.shape[0], -1, -1)

        x = torch.cat((cls_tokens, T2), dim=1)
        x += self.pos_embedding
        x = self.dropout(x)

        for attention, mlp in self.layers:
            x = attention(x, mask=mask)  # go to attention
            x = mlp(x)  # go to MLP_Block

        if self.is_finetune:
            return x.view(batch_size, 10, height // 2, width // 2)

        x = rearrange(x, 'b h w -> b (h w)')
        out_height = self.projection(x)


        return out_height

class TRMODELL(nn.Module):
    def __init__(self, in_channels, dim, depth, heads, mlp_dim, dropout, is_finetune):
        super().__init__()

        self.L = 4
        self.cT = dim
        self.is_finetune = is_finetune

        self.conv2d_features2 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels=128, kernel_size=(3, 3)),
            nn.BatchNorm2d(128),
            nn.ReLU(),
        )

        self.dropout = nn.Dropout(0.1)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, dim))
        self.pos_embedding = nn.Parameter(torch.zeros(1, 5, dim))

        self.token_wA = nn.Parameter(torch.zeros(1, self.L, dim),
                                     requires_grad=True)  # Tokenization parameters
        torch.nn.init.xavier_normal_(self.token_wA)
        self.token_wV = nn.Parameter(torch.zeros(1, dim, self.cT),
                                     requires_grad=True)  # Tokenization parameters
        torch.nn.init.xavier_normal_(self.token_wV)

        self.layers = nn.ModuleList([])
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Residual(LayerNormalize(dim, Attention(dim, heads=heads, dropout=dropout))),
                Residual(LayerNormalize(dim, MLP_Block(dim, mlp_dim, dropout=dropout)))
            ]))

        self._init_weights()

        backbone_in_channels = 640
        self.projection = nn.Sequential(
            nn.Linear(backbone_in_channels, 256, bias = False),
            nn.BatchNorm1d(256),
            nn.ReLU(inplace=True),
            nn.Linear(256, 128, bias=True)
        )

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.xavier_uniform_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.LayerNorm):
                nn.init.constant_(m.bias, 0)
                nn.init.constant_(m.weight, 1.0)

    def forward(self, x, mask=None):
        batch_size, channels, height, width = x.shape
        x = self.conv2d_features2(x)
        x = rearrange(x, 'b c h w -> b (h w) c')

        wa2 = rearrange(self.token_wA, 'b h w -> b w h')  # Transpose
        A2 = torch.einsum('bij,bjk->bik', x, wa2)
        A2 = rearrange(A2, 'b h w -> b w h')  # Transpose
        A2 = A2.softmax(dim=-1)

        VV2 = torch.einsum('bij,bjk->bik', x, self.token_wV)
        T2 = torch.einsum('bij,bjk->bik', A2, VV2)

        cls_tokens = self.cls_token.expand(x.shape[0], -1, -1)

        x = torch.cat((cls_tokens, T2), dim=1)
        x += self.pos_embedding
        x = self.dropout(x)

        for attention, mlp in self.layers:
            x = attention(x, mask=mask)  # go to attention
            x = mlp(x)  # go to MLP_Block

        height = 8
        width = 8

        if self.is_finetune:
            #return x.view(batch_size, x.shape[1] * x.shape[2] // height // width, height, width)          #patch 16
            return x.view(batch_size, x.shape[1] * x.shape[2] // height // width, height, width)          #patch 16

        x = rearrange(x, 'b h w -> b (h w)')
        out_height = self.projection(x)
        return out_height




