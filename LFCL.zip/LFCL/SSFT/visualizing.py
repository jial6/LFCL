import seaborn as sns
from sklearn.manifold import TSNE
import warnings
warnings.filterwarnings('ignore')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# -*- coding: utf-8 -*-
# @Time : 2023/12/6 10:22
# @Author : LiJia

# matplotlib inline
sns.set(style = 'white', context = 'notebook', rc = {'figure.figsize': (14, 10)})

train = pd.read_csv('./Datasets/mnist_train.csv')
test = pd.read_csv('./Datasets/mnist_test.csv')

print(train.head())

y = train.loc[:, 'label'].values
x = train.loc[:, '1x1':].values

x_subset = x[0:10000]
y_subset = y[0:10000]

# Appling t-SNE on the data
tsne = TSNE(random_state = 42, n_components=2, verbose=0, perplexity=40, n_iter=300).fit_transform(x_subset)

# Visualizeing the t-SNE
plt.scatter(tsne[:, 0], tsne[:, 1], s = 5, c = y_subset, cmap = 'Spectral')
plt.gca().set_aspect('equal', 'datalim')
plt.colorbar(boundaries=np.arange(11)-0.5).set_ticks(np.arange(10))
plt.title('Visualizing Kannada MNIST through t-SNE', fontsize = 24);

plt.pause(1000)