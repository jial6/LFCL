#!!!此为新的fine_tune模型
from unittest import runner
import os
import numpy as np
import torch.optim as optim
from torch import autograd
from tqdm import tqdm

from utils import grouper, sliding_window, count_sliding_window, save_model, camel_to_snake
from attention import *
import numpy as np
import pandas as pd


# For plotting
from matplotlib import offsetbox
import matplotlib.pyplot as plt
import matplotlib.patheffects as PathEffects
import seaborn as sns

sns.set(style='white', context='notebook', rc={'figure.figsize':(14,10)})

#For standardising the dat
from sklearn.preprocessing import StandardScaler

#PCA
from sklearn.manifold import TSNE

# def tsne_plot(save_dir, targets, outputs, model = 0):
#     print('generating t-SNE plot...')
#     # tsne_output = bh_sne(outputs)
#     tsne = TSNE(random_state=0)
#     tsne_output = tsne.fit_transform(outputs)
#
#     df = pd.DataFrame(tsne_output, columns=['x', 'y'])
#     df['targets'] = targets
#     plt.rcParams['figure.figsize'] = 10, 8
#
#     # if model == 1:
#     #     plt.rcParams['figure.figsize'] = 40, 40
#
#
#
#     sns.scatterplot(
#         x='x', y='y',
#         hue='targets',
#         #palette=sns.color_palette("hls", 10),
#         palette=sns.color_palette("tab20b", 10),
#         data=df,
#         marker='o',
#         #legend="full",
#         alpha=0.8
#     )
#
#     #plt.legend(loc='upper right')
#     plt.xticks([])
#     plt.yticks([])
#     plt.xlabel('')
#     plt.ylabel('')
#
#     plt.savefig(os.path.join(save_dir, 'tsne.png'), bbox_inches='tight', dpi=300)
#     print('done!')

# def tsne_plot(save_dir, targets, outputs, model = 0):
#     print('generating t-SNE plot...')
#     # tsne_output = bh_sne(outputs)
#     tsne = TSNE(random_state=0)
#     tsne_output = tsne.fit_transform(outputs)
#
#     df = pd.DataFrame(tsne_output, columns=['x', 'y'])
#     df['targets'] = targets
#     plt.rcParams['figure.figsize'] = 10, 8

    # if model == 1:
    #     plt.rcParams['figure.figsize'] = 40, 40

    #plt.legend(loc='upper right')
    # plt.yticks(fontproperties='Times New Roman', size=14)
    # plt.xticks(fontproperties='Times New Roman', size=14)
    # plt.subplot()

    # sns.scatterplot(
    #     x='x', y='y',
    #     hue='targets',
    #     #palette=sns.color_palette("hls", 10),
    #     palette=sns.color_palette("tab20b", 10),
    #     data=df,
    #     marker='o',
    #     #legend="full",
    #     alpha=0.8
    # )

    # plt.scatter(x=tsne_output[:, 0], y=tsne_output[:,1], c=targets, s=9, cmap="tab20b")
    # plt.savefig(os.path.join(save_dir, 'tsne.png'), bbox_inches='tight', dpi=300)
    # print('done!')

def new_train(Dataset_name, net, optimizer, criterion, data_loader, epoch, scheduler=None,
          display_iter=100, device=torch.device('cuda'), display=None,
          val_loader=None, supervision='full'):
    """
    Training loop to optimize a network for several epochs and a specified loss

    Args:
        net: a PyTorch model
        optimizer: a PyTorch optimizer
        data_loader: a PyTorch dataset loader
        epoch: int specifying the number of training epochs
        criterion: a PyTorch-compatible loss function, e.g. nn.CrossEntropyLoss
        device (optional): torch device to use (defaults to CPU)
        display_iter (optional): number of iterations before refreshing the
        display (False/None to switch off).
        scheduler (optional): PyTorch scheduler
        val_loader (optional): validation dataset
        supervision (optional): 'full' or 'semi','simclr'
    """

    if criterion is None:
        raise Exception("Missing criterion. You must specify a loss function.")

    net.to(device)
    # net = nn.DataParallel(net)  # 多GPU运行!!!

    losses = np.zeros(1000000)
    mean_losses = np.zeros(100000000)
    iter_ = 1
    loss_win, val_win = None, None

    targets_list = []
    outputs_list = []

    for e in tqdm(range(1, epoch + 1), desc="Training the network"):

        # Set the network to training mode
        net.train()
        avg_loss = 0.

        for batch_idx, (data,datal, target) in enumerate(data_loader):
            # Load the data into the GPU if required
            data, datal, target = data.to(device), datal.to(device), target.to(device)   # 在DataLoader中已经将Tensor封装成了Variable
            optimizer.zero_grad()
            targets_np = target.data.cpu().numpy()
            if supervision == 'full':
                output = net(data, datal)
                #output_np = output.data.cpu().numpy()

                if e == epoch:
                    targets_list.append(targets_np[:, np.newaxis])
                    #outputs_list.append(output_np)

                loss = criterion(output, target)
            else:
                raise ValueError("supervision mode \"{}\" is unknown.".format(supervision))

            loss.backward()

            optimizer.step()

            avg_loss += loss.item()
            losses[iter_] = loss.item()
            mean_losses[iter_] = np.mean(losses[max(0, iter_ - 100):iter_ + 1])

            if display_iter and iter_ % display_iter == 0:  # 可视化模块
                string = 'Train (epoch {}/{}) [{}/{} ({:.0f}%)]\tLoss: {:.6f}'
                string = string.format(
                    e, epoch, batch_idx *
                    len(data), len(data) * len(data_loader),
                    100. * batch_idx / len(data_loader), mean_losses[iter_])
                update = None if loss_win is None else 'append'
                loss_win = display.line(
                    X=np.arange(iter_ - display_iter, iter_),
                    Y=mean_losses[iter_ - display_iter:iter_],
                    win=loss_win,
                    update=update,
                    opts={'title': "Training loss",
                          'xlabel': "Iterations",
                          'ylabel': "Loss"
                         }
                )
                tqdm.write(string)

            iter_ += 1
            del(data, target, loss)

        metric = avg_loss

        if isinstance(scheduler, optim.lr_scheduler.ReduceLROnPlateau):
            scheduler.step(metric)
        elif scheduler is not None:
            scheduler.step()

    #targets = np.concatenate(targets_list, axis=0)
    #outputs = np.concatenate(outputs_list, axis=0).astype(np.float64)
    #tsne_plot(r'./tsne', targets, outputs)

    # save_model(net.netH, camel_to_snake(str(net.netH.__class__.__name__)), Dataset_name, epoch=e, metric=1)
    # save_model(net.netL, camel_to_snake(str(net.netL.__class__.__name__)), Dataset_name + "_mt", epoch=e, metric=1)




def test(net, img, imgl, gt, hyperparams):
    """
   # Test a model on a specific image
    """
    net.eval()
    patch_size = hyperparams['patch_size']
    center_pixel = hyperparams['center_pixel']
    batch_size, device = hyperparams['batch_size'], hyperparams['device']
    n_classes = hyperparams['n_classes']

    kwargs = {'step': hyperparams['test_stride'], 'window_size': (patch_size, patch_size)}
    probs = np.zeros(img.shape[:2] + (n_classes,))  # 增加一个维度2（H,W,类别）

    iterations = count_sliding_window(img, **kwargs) // batch_size

    for batch, batchl in tqdm(grouper(batch_size, sliding_window(img, **kwargs), sliding_window(imgl, **kwargs)),
                      total=(iterations),
                      desc="Inference on the image"
                      ):
        # targets = labels[patch_size // 2, patch_size // 2]
        # targets_np = targets.data.cpu().numpy()

        with torch.no_grad():
            if patch_size == 1:
                data = [b[0][0, 0] for b in batch]
                data = np.copy(data)
                data = torch.from_numpy(data)
            else:
                data = [b[0] for b in batch]
                datal = [b[0] for b in batchl]
                data = np.copy(data)
                datal = np.copy(datal)
                data = data.transpose(0, 3, 1, 2)
                datal = datal.transpose(0, 3, 1, 2)

                data = torch.from_numpy(data)
                datal = torch.from_numpy(datal)
                # data = data.unsqueeze(1)              # 3DConv时执行

            indices = [b[1:] for b in batch]
            data = data.to(device)
            datal = datal.to(device)

            output = net(data, datal)

            if isinstance(output, tuple):
                output = output[0]
            output = output.to('cpu')  # 将cpu 改为 cuda

            if patch_size == 1 or center_pixel:
                output = output.numpy()
            else:
                output = np.transpose(output.numpy(), (0, 2, 3, 1))
            for (x, y, w, h), out in zip(indices, output):
                if center_pixel:
                    # probs[x, y] += out
                    probs[x + w // 2, y + h // 2] += out
                    # probs[x:x + w, y:y + h] += out
                else:
                    probs[x:x + w, y:y + h] += out

    return probs



