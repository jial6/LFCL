## Houston2013
#### 3-7
    Class Accuracy :
        Undefined: 0.9417 +- 0.0493
        Healthy grass: 0.9625 +- 0.0453
        Stressed grass: 0.9875 +- 0.0184
        Synthetic grass: 0.9737 +- 0.0217
        Trees: 0.9983 +- 0.0038
        Soil: 0.9413 +- 0.0744
        Water: 0.9627 +- 0.0227
        Residential: 0.8547 +- 0.0700
        Commercial: 0.8969 +- 0.0324
        Road: 0.8712 +- 0.0904
        Highway: 0.8985 +- 0.0581
        Railway: 0.7907 +- 0.0576
        Parking Lot 1: 0.9473 +- 0.0227
        Parking Lot 2: 1.0000 +- 0.0000
        Tennis Court: 0.9577 +- 0.0562
---
Overall_Accuracy: 92.4477 +- 1.1682
---
Average_Accuracy: 0.9323 +- 0.0110
---
Kappa: 0.9184 +- 0.0126


Process finished with exit code 0


### ours
#### hsi加clustering contrastive 
    Undefined: 0.9284 +- 0.0434
	Healthy grass: 0.9285 +- 0.0653
	Stressed grass: 0.9719 +- 0.0310
	Synthetic grass: 0.9629 +- 0.0282
	Trees: 0.9982 +- 0.0043
	Soil: 0.9616 +- 0.0532
	Water: 0.9615 +- 0.0299
	Residential: 0.8556 +- 0.0574
	Commercial: 0.8886 +- 0.0270
	Road: 0.8684 +- 0.1009
	Highway: 0.9214 +- 0.0505
	Railway: 0.8255 +- 0.0589
	Parking Lot 1: 0.9495 +- 0.0292
	Parking Lot 2: 0.9998 +- 0.0007
	Tennis Court: 0.9709 +- 0.0286
    ---
    Overall_Accuracy: 92.3772 +- 1.4635
    ---
    Average_Accuracy: 0.9328 +- 0.0130
    ---
    Kappa: 0.9176 +- 0.0158


### siam
#### 不加clustering loss
    Undefined: 0.8798 +- 0.0385
	Healthy grass: 0.8554 +- 0.0669
	Stressed grass: 0.9699 +- 0.0369
	Synthetic grass: 0.9743 +- 0.0241
	Trees: 0.9984 +- 0.0041
	Soil: 0.9381 +- 0.0569
	Water: 0.9428 +- 0.0329
	Residential: 0.8525 +- 0.0797
	Commercial: 0.8327 +- 0.0776
	Road: 0.8136 +- 0.0846
	Highway: 0.9517 +- 0.0350
	Railway: 0.8280 +- 0.0538
	Parking Lot 1: 0.9638 +- 0.0263
	Parking Lot 2: 1.0000 +- 0.0000
	Tennis Court: 0.9766 +- 0.0456
    ---
    Overall_Accuracy: 90.6378 +- 1.5096
    ---
    Average_Accuracy: 0.9185 +- 0.0112
    ---
    Kappa: 0.8989 +- 0.0163


### siam_loss_c
#### hsi和lidar都加clustering loss

	Undefined: 0.9342 +- 0.0480
	Healthy grass: 0.8961 +- 0.0780
	Stressed grass: 0.9700 +- 0.0258
	Synthetic grass: 0.9718 +- 0.0265
	Trees: 0.9964 +- 0.0046
	Soil: 0.9352 +- 0.0785
	Water: 0.9693 +- 0.0237
	Residential: 0.7744 +- 0.1257
	Commercial: 0.8289 +- 0.0681
	Road: 0.7870 +- 0.1188
	Highway: 0.9380 +- 0.0372
	Railway: 0.8577 +- 0.0689
	Parking Lot 1: 0.9584 +- 0.0268
	Parking Lot 2: 0.9998 +- 0.0007
	Tennis Court: 0.9863 +- 0.0220

    Overall_Accuracy: 90.8737 +- 1.5894
    Average_Accuracy: 0.9202 +- 0.0116
    Kappa: 0.9014 +- 0.0171

## Trento
### ours
    Class Accuracy :
        Undefined: 0.9850 +- 0.0094
        Apple Tree: 0.9852 +- 0.0174
        Building: 0.9765 +- 0.0299
        Ground: 1.0000 +- 0.0000
        Wood: 0.9992 +- 0.0019
        Vineyard: 0.9314 +- 0.0223
    ---
    Overall_Accuracy: 98.8721 +- 0.2320
    ---
    Average_Accuracy: 0.9795 +- 0.0054
    ---
    Kappa: 0.9849 +- 0.0031

### siam
    Class Accuracy :
	Undefined: 0.9839 +- 0.0085
	Apple Tree: 0.9939 +- 0.0070
	Building: 0.9443 +- 0.0383
	Ground: 1.0000 +- 0.0000
	Wood: 0.9828 +- 0.0246
	Vineyard: 0.8967 +- 0.0269
    ---
    Overall_Accuracy: 97.9578 +- 0.7322
    ---
    Average_Accuracy: 0.9669 +- 0.0069
    ---
    Kappa: 0.9728 +- 0.0096

#### Muufl
    Class Accuracy :
        Undefined: 0.8795 +- 0.0132
        Trees: 0.7162 +- 0.0486
        Mostly grass: 0.5002 +- 0.1156
        Mixed ground surface: 0.8011 +- 0.0942
        Dirt and sand: 0.7174 +- 0.0811
        Road: 0.9971 +- 0.0078
        Water: 0.8228 +- 0.0504
        Building shadow: 0.8968 +- 0.0606
        Building: 0.4704 +- 0.0450
        Sidewalk: 0.6214 +- 0.1056
        Yellow curb: 0.9390 +- 0.0603
    ---
    Overall_Accuracy: 78.4615 +- 1.5275
    ---
    Average_Accuracy: 0.7602 +- 0.0137
    ---
    Kappa: 0.7244 +- 0.0185












